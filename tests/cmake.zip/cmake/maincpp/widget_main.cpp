#include "totaltest.h"

TEST_WIDGET_MAIN
