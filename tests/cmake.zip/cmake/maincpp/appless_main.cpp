#include "totaltest.h"

TEST_MAIN
