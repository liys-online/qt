#include "totaltest.h"

TEST_GUI_MAIN
