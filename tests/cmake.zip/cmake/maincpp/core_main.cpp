#include "totaltest.h"

TEST_CORE_MAIN
